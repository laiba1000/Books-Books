const express = require('express');
const cors = require('cors');
const pool = require('./db');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

app.get('/',async(req,res)=>{
    try{
        res.json('Welcome To Student API');
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.get('/members',async(req,res)=>{
    try{
        const result = await pool.query('select * from members');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/members', async (req, res) => {
  const { member_id, name, email, phone, address, join_date} = req.body;
  try {
    await pool.query(
      'INSERT INTO members (member_id, name, email, phone, address, join_date) VALUES ($1, $2, $3, $4, $5, $6)',
      [member_id, name, email, phone, address, join_date]
    );
    res.send('Member added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding member');
  }
});

app.get('/authors',async(req,res)=>{
    try{
        const result = await pool.query('select * from authors');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/authors', async (req, res) => {
  const { author_id, name } = req.body;
  try {
    await pool.query(
      'INSERT INTO authors (author_id, name) VALUES ($1, $2)',
      [author_id, name]
    );
    res.send('Author added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding author');
  }
});


app.get('/publishers',async(req,res)=>{
    try{
        const result = await pool.query('select * from publishers');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/publishers', async (req, res) => {
  const { publisher_id, name } = req.body;
  try {
    await pool.query(
      'INSERT INTO publishers (publisher_id, name) VALUES ($1, $2)',
      [publisher_id, name]
    );
    res.send('Publisher added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding publisher');
  }
});

app.put('/publishers/:id', async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    await pool.query(
      'UPDATE publishers SET name = $1 WHERE publisher_id = $2',
      [name, id]
    );
    res.send('Publisher updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating publisher');
  }
});

app.delete('/publishers/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM publishers WHERE publisher_id = $1', [id]);
    res.send('Publisher deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting publisher');
  }
});

app.get('/categories',async(req,res)=>{
    try{
        const result = await pool.query('select * from categories');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/categories', async (req, res) => {
  const { category_id, category_name } = req.body;
  try {
    await pool.query(
      'INSERT INTO categories (category_id, category_name) VALUES ($1, $2)',
      [category_id, category_name]
    );
    res.send('Category added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding category');
  }
});

app.put('/categories/:id', async (req, res) => {
  const { id } = req.params;
  const { category_name } = req.body;
  try {
    await pool.query(
      'UPDATE categories SET category_name = $1 WHERE category_id = $2',
      [category_name, id]
    );
    res.send('Category updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating category');
  }
});

app.delete('/categories/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM categories WHERE category_id = $1', [id]);
    res.send('Category deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting category');
  }
});


app.get('/books',async(req,res)=>{
    try{
        const result = await pool.query('select * from books');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/books', async (req, res) => {
  const {
    book_id,
    title,
    author_id,
    publisher_id,
    category_id,
    year_published,
    total_copies,
    available_copies
  } = req.body;

  try {
    await pool.query(
      `INSERT INTO books (
        book_id, title, author_id, publisher_id, category_id,
        year_published, total_copies, available_copies
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [
        book_id,
        title,
        author_id,
        publisher_id,
        category_id,
        year_published,
        total_copies,
        available_copies
      ]
    );
    res.send('Book added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding book');
  }
});


app.get('/staff',async(req,res)=>{
    try{
        const result = await pool.query('select * from staff');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

app.post('/staff', async (req, res) => {
  const { staff_id, name, position, email } = req.body;

  try {
    await pool.query(
      'INSERT INTO staff (staff_id, name, position, email) VALUES ($1, $2, $3, $4)',
      [staff_id, name, position, email]
    );
    res.send('Staff added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding staff');
  }
});

app.put('/staff/:id', async (req, res) => {
  const { id } = req.params;
  const { name, position, email } = req.body;

  try {
    await pool.query(
      'UPDATE staff SET name = $1, position = $2, email = $3 WHERE staff_id = $4',
      [name, position, email, id]
    );
    res.send('Staff updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating staff');
  }
});


app.delete('/staff/:id', async (req, res) => {
  const { id } = req.params;

  try {
    await pool.query('DELETE FROM staff WHERE staff_id = $1', [id]);
    res.send('Staff deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting staff');
  }
});


app.get('/borrow',async(req,res)=>{
    try{
        const result = await pool.query('select * from borrow');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

// Add borrow
app.post('/borrow', async (req, res) => {
  const { borrow_id, member_id, book_id, borrow_date, due_date, return_date } = req.body;
  try {
    await pool.query(
      'INSERT INTO borrow (borrow_id, member_id, book_id, borrow_date, due_date, return_date) VALUES ($1, $2, $3, $4, $5, $6)',
      [borrow_id, member_id, book_id, borrow_date, due_date, return_date]
    );
    res.send('Borrow record added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding borrow record');
  }
});

// Update borrow
app.put('/borrow/:id', async (req, res) => {
  const { id } = req.params;
  const { member_id, book_id, borrow_date, due_date, return_date } = req.body;
  try {
    await pool.query(
      'UPDATE borrow SET member_id = $1, book_id = $2, borrow_date = $3, due_date = $4, return_date = $5 WHERE borrow_id = $6',
      [member_id, book_id, borrow_date, due_date, return_date, id]
    );
    res.send('Borrow record updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating borrow record');
  }
});

// Delete borrow
app.delete('/borrow/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM borrow WHERE borrow_id = $1', [id]);
    res.send('Borrow record deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting borrow record');
  }
});


app.get('/fines',async(req,res)=>{
    try{
        const result = await pool.query('select * from fines');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

// Add fine
app.post('/fines', async (req, res) => {
  const { fine_id, borrow_id, fine_amount, paid } = req.body;
  try {
    await pool.query(
      'INSERT INTO fines (fine_id, borrow_id, fine_amount, paid) VALUES ($1, $2, $3, $4)',
      [fine_id, borrow_id, fine_amount, paid]
    );
    res.send('Fine added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding fine');
  }
});

// Update fine
app.put('/fines/:id', async (req, res) => {
  const { id } = req.params;
  const { borrow_id, fine_amount, paid } = req.body;
  try {
    await pool.query(
      'UPDATE fines SET borrow_id = $1, fine_amount = $2, paid = $3 WHERE fine_id = $4',
      [borrow_id, fine_amount, paid, id]
    );
    res.send('Fine updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating fine');
  }
});

// Delete fine
app.delete('/fines/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM fines WHERE fine_id = $1', [id]);
    res.send('Fine deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting fine');
  }
});


app.get('/reservations',async(req,res)=>{
    try{
        const result = await pool.query('select * from reservations');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

// Add reservation
app.post('/reservations', async (req, res) => {
  const { reservation_id, book_id, member_id, reservation_date } = req.body;
  try {
    await pool.query(
      'INSERT INTO reservations (reservation_id, book_id, member_id, reservation_date) VALUES ($1, $2, $3, $4)',
      [reservation_id, book_id, member_id, reservation_date]
    );
    res.send('Reservation added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding reservation');
  }
});

// Update reservation
app.put('/reservations/:id', async (req, res) => {
  const { id } = req.params;
  const { book_id, member_id, reservation_date } = req.body;
  try {
    await pool.query(
      'UPDATE reservations SET book_id = $1, member_id = $2, reservation_date = $3 WHERE reservation_id = $4',
      [book_id, member_id, reservation_date, id]
    );
    res.send('Reservation updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating reservation');
  }
});

// Delete reservation
app.delete('/reservations/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM reservations WHERE reservation_id = $1', [id]);
    res.send('Reservation deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting reservation');
  }
});


app.get('/returns',async(req,res)=>{
    try{
        const result = await pool.query('select * from returns');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message});
    }
});

// Add return
app.post('/returns', async (req, res) => {
  const { return_id, borrow_id, return_date, condition_note } = req.body;
  try {
    await pool.query(
      'INSERT INTO returns (return_id, borrow_id, return_date, condition_note) VALUES ($1, $2, $3, $4)',
      [return_id, borrow_id, return_date, condition_note]
    );
    res.send('Return added');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding return');
  }
});

// Update return
app.put('/returns/:id', async (req, res) => {
  const { id } = req.params;
  const { borrow_id, return_date, condition_note } = req.body;
  try {
    await pool.query(
      'UPDATE returns SET borrow_id = $1, return_date = $2, condition_note = $3 WHERE return_id = $4',
      [borrow_id, return_date, condition_note, id]
    );
    res.send('Return updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating return');
  }
});

// Delete return
app.delete('/returns/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM returns WHERE return_id = $1', [id]);
    res.send('Return deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting return');
  }
});

app.put('/members/:id', async (req, res) => {
  const { id } = req.params;
  const { name, email, phone, address, join_date } = req.body;
  try {
    await pool.query(
      'UPDATE members SET name = $1, email = $2, phone = $3, address = $4, join_date = $5 WHERE member_id = $6',
      [name, email, phone, address, join_date, id]
    );
    res.send('Member updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating member');
  }
});


app.delete('/members/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM members WHERE member_id = $1', [id]);
    res.send('Member deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting member');
  }
});

//Login route for admin
app.post('/admin/login', (req, res) => {
  console.log('Login attempt:', req.body); // Add this line
  const { username, password } = req.body;
  if (username === 'admin' && password === 'alizalaiba100') {
    res.sendStatus(200);
  } else {
    res.sendStatus(401);
  }
});

// Create feedback table if not exists (run once in DB):
// CREATE TABLE feedback (feedback_id SERIAL PRIMARY KEY, member_id INT, feedback TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);


app.get('/feedback', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM feedback ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching feedback');
  }
});

app.put('/authors/:id', async (req, res) => {
  const { id } = req.params;
  const { name } = req.body;
  try {
    await pool.query(
      'UPDATE authors SET name = $1 WHERE author_id = $2',
      [name, id]
    );
    res.send('Author updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating author');
  }
});

// Delete author
app.delete('/authors/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM authors WHERE author_id = $1', [id]);
    res.send('Author deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting author');
  }
});

// Update book
app.put('/books/:id', async (req, res) => {
  const { id } = req.params;
  const {
    title,
    author_id,
    publisher_id,
    category_id,
    year_published,
    total_copies,
    available_copies
  } = req.body;
  try {
    await pool.query(
      `UPDATE books SET
        title = $1,
        author_id = $2,
        publisher_id = $3,
        category_id = $4,
        year_published = $5,
        total_copies = $6,
        available_copies = $7
      WHERE book_id = $8`,
      [title, author_id, publisher_id, category_id, year_published, total_copies, available_copies, id]
    );
    res.send('Book updated');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error updating book');
  }
});

// Delete book
app.delete('/books/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM books WHERE book_id = $1', [id]);
    res.send('Book deleted');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting book');
  }
});

app.post('/feedback', async (req, res) => {
  const { feedback } = req.body;
  try {
    await pool.query(
      'INSERT INTO feedback (feedback) VALUES ($1)',
      [feedback]
    );
    res.sendStatus(200);
  } catch (err) {
    console.error(err);
    res.status(500).send('Error saving feedback');
  }
});




const PORT = process.env.PORT;
app.listen(PORT,()=>{
    console.log(`Connected Successfully.....Running on Port ${PORT}`)
}); 
